from sam3d_objects.model.backbone.generator.shortcut.model import ShortCut
from ..basic import BasicTrainer